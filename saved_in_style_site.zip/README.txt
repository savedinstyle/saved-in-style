
saved in style site

how to run on your computer
1. open the folder in your code editor
2. use a simple server
   - with python run:  python -m http.server 8000
   - open http://localhost:8000 in your browser

how to publish free with github pages
1. create a repo named username.github.io
2. upload all files from this folder to that repo
3. visit https://username.github.io in two to three minutes
4. edit the text in the html files to make it yours
